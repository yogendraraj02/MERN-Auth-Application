

export default function SignUp() {
  return (
    <div>SignUp</div>
  )
}
